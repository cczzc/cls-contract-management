package contract;
import java.sql.*;

public class SignUp {
	
	public static boolean isNumeric(String str){
		  for (int i = 0; i < str.length(); i++){
		   if (!Character.isDigit(str.charAt(i))){
		    return false;
		   }
		  }
		  return true;
	}

	public static int SignUpCheck(String name, String account,String password,String number){
		String driver = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://127.0.0.1:3306/contract?useUnicode=true&amp;" +
			"characterEncoding=utf8&useSSL=true";
		String user = "root";
		String password1 = "264737";
		
		if (name==null || name.length()<=0){
			return 1;//����Ϊ��
			
		}
		else if(account==null || account.length()<6){
			return 2;//�˺�̫��
		}
		else if(password==null || password.length()<6){
			return 3;//����̫��
		}
		else if(number==null || isNumeric(number)==false || number.length()!=11){
			return 4;//�ֻ��Ÿ�ʽ����ȷ
		}
		else{
			try {
				Class.forName(driver);

				Connection conn = DriverManager.getConnection(url, user, password1);
				Statement statement = conn.createStatement();
				String sql = "insert into UserInfo(name,account,password,number) value(" + name +','+ account +',' + password +',' + number+ ")";
				statement.execute(sql); 
				
			}catch(ClassNotFoundException e) {    
				e.printStackTrace();   
				} catch(SQLException e) {   
				e.printStackTrace();   
				} catch(Exception e) {   
				e.printStackTrace();   
				}   
	}return 0;//ע��ɹ�
	}	
}
