package contract;
import java.sql.*;

public class SignIn {
	public static boolean SignInCheck(String account,String password){
		String driver = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://127.0.0.1:3306/contract?useUnicode=true&amp;" +
			"characterEncoding=utf8&useSSL=true";
		String user = "root";
		String password1 = "264737";
		try {
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url, user, password1);
			Statement statement = conn.createStatement();
			String sql ="select count(*) as rowCount from UserInfo where account =" +account +" and password = " + password;
			
			ResultSet rs = statement.executeQuery(sql); 
			rs.next();
			int rowCount = rs.getInt("rowCount");
			if (rowCount>0){
				return true;//�˺�����ƥ��
			}
			
		}catch(ClassNotFoundException e) {    
			e.printStackTrace();   
			} catch(SQLException e) {   
			e.printStackTrace();   
			} catch(Exception e) {   
			e.printStackTrace();   
			}   
		return false;//�˺����벻ƥ��
	}
}
