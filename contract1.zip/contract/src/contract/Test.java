package contract;

public class Test {

	public static void main(String[] args) {
		// TODO �Զ����ɵķ������
		if(SignIn.SignInCheck("\"123456\"","\"aaaaaaaa\"") == true)
		{
			System.out.println("success");
		}
		
		
	}

}
